<?php
namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Register extends Model {

    protected $table = 'users';
    protected $primaryKey = 'user_id';
    protected $fillable = ['user_pass', 'user_first_name', 'user_last_name', 'user_phone'];

}
