<?php


namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class Login extends Model {
    

    protected $table = 'users';
    protected $primaryKey = 'user_id';
    public $timestamps = false;

    public function getUser($email) {
        return Login::where('user_email', $email)->get();
    }

    public function firstUser($email) {
        return Login::where('user_email', $email)->first();
    }

    public function updateTime($email){
        Login::where('user_email', $email)
            ->update(['user_last_access'=>date('Y-m-d H:i:s'),
                'user_attempt' => 0,
                'user_status' => 1]);
    }
    public function updateUser($tel, $pass, $fname, $lname){
        Login::where('user_email', Session::get('user_email'))
            ->update([
                'user_phone'=>$tel,
                'user_password'=>bcrypt($pass),
                'user_first_name'=>$fname,
                'user_last_name'=>$lname,
            ]);
    }

}
