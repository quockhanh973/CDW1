<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Http\Controllers;

use App\Model\Login;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\MessageBag;
use App\Http\Controllers\DB;

class LoginController extends Controller {

    use AuthenticatesUsers;

    public function index() {
        return view('/login');
    }

    protected function hasTooManyLoginAttempts(Request $request) {
        return $this->limiter()->tooManyAttempts(
                        $this->throttleKey($request), 3, 30 // <--- Change this
        );
    }

    public function postLogin(Request $request) {
        $user = new Login();
        $validator = Validator::make($request->all(), [
                    'user_email' => 'required|email',
                    'user_password' => 'required|min:6'
                        ], [
                    'user_email.required' => 'Email is required',
                    'user_email.email' => 'Email is wrong format',
                    'user_password.required' => 'Password is required',
                    'user_password.min' => 'Password is greater than 6',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        } else {
            $email = $request->input('user_email');
            $password = $request->input('user_password');

            $data = $user->firstUser($email);

            if ($data->user_status == 0) {
                $minutes = round((time() - strtotime($data->user_last_access)) / 60);
                if ($minutes <= 30) {
                    $errors = new MessageBag(['errorlogin' => 'The account has been lock']);
                    return redirect('/login')->withInput()->withErrors($errors);
                } else {
                    $user->updateTime($email);

                    if (Auth::attempt(['user_email' => $email, 'password' => $password])) {
                        Session::put('user_first_name', $data->user_first_name);
                        Session::put('user_last_name', $data->user_last_name);
                        Session::put('user_email', $data->user_email);
                        Session::put('login', TRUE);

                        $user->updateTime($email);

                        return redirect()->route('index')->with('success', 'Login success');
                    } else {
                        DB::table('users')
                                ->where('user_email', $email)
                                ->update(['user_attempt' => ($data->user_attempt) + 1,
                                    'user_last_access' => date('Y-m-d H:i:s'),]);

                        if (($data->user_attempt) + 1 > 3) {
                            DB::table('users')
                                    ->where('user_email', $email)
                                    ->update(['user_status' => 0,
                                        'user_last_access' => date('Y-m-d H:i:s'),]);
                            $errors = new MessageBag(['errorlogin' => 'The account has been lock']);
                            return redirect('/login')->withInput()->withErrors($errors);
                        }

                        $errors = new MessageBag(['errorlogin' => 'Email or password was wrong']);
                        return redirect('/login')->withInput($request->except('user_password'))->withErrors($errors);
                    }
                }
            } else {
                if (Auth::attempt(['user_email' => $email, 'password' => $password])) {
                    Session::put('user_first_name', $data->user_first_name);
                    Session::put('user_last_name', $data->user_last_name);
                    Session::put('user_email', $data->user_email);
                    Session::put('login', TRUE);

                    $user->updateTime($email);

                    return redirect()->route('index')->with('success', 'Login success');
                } else {
                    DB::table('users')
                            ->where('user_email', $email)
                            ->update(['user_attempt' => ($data->user_attempt) + 1,
                                'user_last_access' => date('Y-m-d H:i:s'),]);

                    if (($data->user_attempt) + 1 > 3) {
                        DB::table('users')
                                ->where('user_email', $email)
                                ->update(['user_status' => 0,
                                    'user_last_access' => date('Y-m-d H:i:s'),]);
                        $errors = new MessageBag(['errorlogin' => 'The account has been lock']);
                        return redirect('/login')->withInput()->withErrors($errors);
                    }

                    $errors = new MessageBag(['errorlogin' => 'Email or password was wrong']);
                    return redirect('/login')->withInput($request->except('user_password'))->withErrors($errors);
                }
            }
        }
    }

    public function logout() {
        Auth::logout();
        Session::put('login', FALSE);
        return redirect()->route('login');
    }

}
